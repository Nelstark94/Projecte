<?php 
/**
 * Concept: Add your own front page slider code
 * Copyright 2011 www.gradientpixels.ca
 * Theme: Incantation
 */
?>
				<div id="showcase-slider">
					<div style="margin:auto; width:960px; border:1px solid <?php echo of_get_option('showcase_border'); ?>; position:relative;">
<!-- Replace this line with your own slider code -->
					</div>
				</div>
