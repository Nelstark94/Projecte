<?php
/* template name:Full page
*/
get_header(); ?>

<!-- Full page wrapper Start -->
<div id="full_page_wrapper">

<div class="header">
<h2><span><?php bloginfo('name'); ?> //</span> theme shared on W P L O C K E R . C O M - 404 </h2>
</div>

<div id="post_wrapper">


<!-- Body Start -->
<div id="body">
<div class="four0four">
    <p class="huge"> BOOM 404!</p>
    Page not found, sorry :(
</div>


</div>
<!-- Body end -->

<div class="clear"></div>
</div>

</div>
<!-- Full page wrapper end -->

<?php get_footer(); ?>